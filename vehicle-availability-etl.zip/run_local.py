from app.lambda_handler import lambda_handler

if __name__ == "__main__":
    print(lambda_handler({}, {}))
