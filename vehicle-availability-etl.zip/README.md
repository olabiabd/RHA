# Vehicle Availability ETL

ETL pipeline for vehicle availability data.